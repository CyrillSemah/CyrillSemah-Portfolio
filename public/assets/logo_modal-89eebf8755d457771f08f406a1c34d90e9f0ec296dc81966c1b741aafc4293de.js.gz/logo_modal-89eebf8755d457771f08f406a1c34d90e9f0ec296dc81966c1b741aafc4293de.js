// Ce fichier n'est plus utilisé car nous utilisons maintenant une solution CSS pure pour l'affichage du logo au survol;
